/*///()
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TransportadoraCodigos;

public interface VeiculoDao {

    public void cadastarVeiculo();

    public void verVeiculos();

    public void gerarRoteiro();

    public void gerarCarga();

}
