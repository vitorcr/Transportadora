package TransportadoraCodigos;

import javax.swing.JOptionPane;
import TransportadoraTelas.CadastroObjetos;

public class DAO {

    Carga carga = new Carga();
    Garagem garagem = new Garagem();
    Empregados empregados = new Empregados();
    CadastroObjetos telacadastro = new CadastroObjetos();

//=====================================================================OBJETO===
//====================================================================VEICULO===
//==================================================================MOTORISTA===
//==============================================================================
    public void separarCarga(Veiculo veiculo) {
        //veiculo.gerarCarga();
    }

    public void vincularMotoristaVeiculo(Motorista motorista, Veiculo veiculo) {

        if (veiculo.disponibilidade == true) {

            if (verificaCNH(motorista, veiculo)) {
                motorista.setVeiculo(veiculo);
                veiculo.disponibilidade = false;
            } else {
                JOptionPane.showInputDialog("O motorista não possui CNH nescessária para este tipo de veículo!");
            }

        } else {
            JOptionPane.showInputDialog("O veículo não está disponível!");
        }

    }

    public boolean verificaCNH(Motorista motorista, Veiculo veiculo) {

        if (motorista.getTipoCNH() == veiculo.getCNH()) {
            return true;
        } else {
            return false;
        }
    }

}
