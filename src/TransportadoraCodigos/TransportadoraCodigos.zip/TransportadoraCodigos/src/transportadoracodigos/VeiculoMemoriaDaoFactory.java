/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TransportadoraCodigos;

public class VeiculoMemoriaDaoFactory implements VeiculoDao {

    Garagem garagem = new Garagem();
    Veiculo veiculo = new Veiculo();

    @Override
    public void cadastarVeiculo() {
        garagem.adicionarVeiculo(veiculo.solicitaVeiculo());
    }

    @Override
    public void verVeiculos() {
        garagem.verVeiculos();
    }

    @Override
    public void gerarRoteiro() {
        Roteiro roteiro = new Roteiro();
        roteiro.gerarRoteiroEntrega(veiculo);
    }

    @Override
    public void gerarCarga() {
        Carga carga = new Carga();
        carga.gerarCargaVeiculo(veiculo);
    }

}
