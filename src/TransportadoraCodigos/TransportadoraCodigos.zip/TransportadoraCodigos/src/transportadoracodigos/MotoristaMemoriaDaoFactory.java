/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TransportadoraCodigos;

/**
 *
 * @author Vitor
 */
public class MotoristaMemoriaDaoFactory implements MotoristaDao {

    Empregados empregados = new Empregados();
    Motorista motorista = new Motorista ();
    
    @Override
    public void cadastrarMotorista() {
        empregados.adicionarMotorista(motorista.solicitaMotorista());
    }

    @Override
    public void verMotorista() {
        empregados.verMotoristas();
    }

}
